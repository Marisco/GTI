class modEspespecialidade {

    constructor(Data) {
        this.numero = Data.numero;
        this.nome = Data.nome;
    };
}

module.exports = {
    modEspespecialidade
}