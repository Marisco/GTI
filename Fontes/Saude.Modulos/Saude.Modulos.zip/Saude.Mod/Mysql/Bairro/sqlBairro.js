const sqlListar =
    " SELECT numero, nome " +
    "  FROM bairro        " 

module.exports = {
    sqlListar
};
