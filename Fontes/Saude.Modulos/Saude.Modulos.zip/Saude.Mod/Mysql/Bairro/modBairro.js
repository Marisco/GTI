class modBairro {
    
    constructor(Data) {
        this.numero = Data.numero;
        this.nome = Data.nome;
        
    };      
}

module.exports ={
    modBairro
    }