const sqlListar =
    " SELECT numero, nome     " +
    "  FROM unidade           " +
    " WHERE atendimento = 'S' " 
    

module.exports = {
    sqlListar
};
